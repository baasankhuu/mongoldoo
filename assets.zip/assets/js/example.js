$(function () {
  eval($('#code').text());
  
});